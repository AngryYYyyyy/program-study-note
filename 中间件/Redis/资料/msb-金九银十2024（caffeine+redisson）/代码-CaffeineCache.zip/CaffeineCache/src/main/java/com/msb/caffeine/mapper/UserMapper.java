package com.msb.caffeine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.msb.caffeine.bean.User;

/**
 * MyBatisPlus中的Mapper接口继承自BaseMapper
 */
public interface UserMapper extends BaseMapper<User> {


}
