package com.msb.caffeine.cache;

public enum CacheType {
    FULL,   //存取
    PUT,    //只存
    DELETE  //删除
}
