# RocketMQ中的Remoting

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/185d49497c424c19b786f7b87ca959de.png)

**NettyRemotingServer与NettyRemotingClient是**基于netty的底层通信实现。

所有服务间的交互都基于此模块。Netty Remoting Server是服务端，Netty Remoting Client是客户端

我们再回顾一下，在NameServer中是如何启动服务端和发起客户端调用的。

通过这样的方式快速查找一个组件在一个工程中的使用。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/f7216475b22642a09c33a1067600fba9.png)

## Netty入门基础知识(适合于Netty基础薄弱的学员)

### Netty程序演示

代码如下：

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/ad3fe3cb649e4c43baf551df65fc3d5b.png)

#### EventLoop

EventLoop暂时可以看成一个线程、EventLoopGroup自然就可以看成线程组。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/d56542aab8c342828ce7a608e80b2bcf.png)

网络编程里，“服务器”和“客户端”实际上表示了不同的网络行为；换句话说，是监听传入的连接还是建立到一个或者多个进程的连接。因此，有两种类型的引导：一种用于客户端（简单地称为Bootstrap），而另一种（ServerBootstrap）用于服务器。无论你的应用程序使用哪种协议或者处理哪种类型的数据，唯一决定它使用哪种引导类的是它是作为一个客户端还是作为一个服务器。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/0323cc4b34be422fbfc17ca75a353fe8.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/7ef724c5fc3349b385c0a2225f84516c.png)

ServerBootstrap将绑定到一个端口，因为服务器必须要监听连接，而Bootstrap 则是由想要连接到远程节点的客户端应用程序所使用的。

引导一个客户端只需要一个EventLoopGroup，但是一个ServerBootstrap 则需要两个，因为服务器需要两组不同的Channel。第一组将只包含一个ServerChannel，代表服务器自身的已绑定到某个本地端口的正在监听的套接字。而第二组将包含所有已创建的用来处理传入客户端连接（对于每个服务器已经接受的连接都有一个）的Channel。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/99b4ed97f3e84474b9bf97a76f842c89.png)

Channel 是Java NIO 的一个基本构造。

它代表一个到实体（如一个硬件设备、一个文件、一个网络套接字或者一个能够执行一个或者多个不同的I/O操作的程序组件）的开放连接，如读操作和写操作

目前，可以把Channel 看作是传入（入站）或者传出（出站）数据的载体。因此，它可以被打开或者被关闭，连接或者断开连接。

#### 事件和ChannelHandler、ChannelPipeline

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/09846ec38b084d19b78f1bd8a1b73bd0.png)

Netty 使用不同的事件来通知我们状态的改变或者是操作的状态。这使得我们能够基于已经发生的事件来触发适当的动作。

**可能由入站数据或者相关的状态更改而触发的事件包括：**

连接已被激活或者连接失活；数据读取；用户事件；错误事件。

**出站事件是未来将会触发的某个动作的操作结果，这些动作包括：**

打开或者关闭到远程节点的连接；将数据写到或者冲刷到套接字。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1657526666011/8c95be4444794e96978d9689547aa957.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/ea22d10c005343fa8d97cad6a5b956ba.png)

#### ChannelFuture

Netty 中所有的I/O 操作都是异步的。

JDK 预置了interface java.util.concurrent.Future，Future 提供了一种在操作完成时通知应用程序的方式。这个对象可以看作是一个异步操作的结果的占位符；它将在未来的某个时刻完成，并提供对其结果的访问。但是其所提供的实现，只允许手动检查对应的操作是否已经完成，或者一直阻塞直到它完成。这是非常繁琐的，所以Netty提供了它自己的实现——ChannelFuture，用于在执行异步操作的时候使用。

**每个Netty 的出站I/O操作都将返回一个 ChannelFuture 。**

## Remoting源码分析

1、初始化网络组件

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/64e2247df4cc477ab6698b54b9d1b8df.png)

2、客户端组件调用

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/fcba70ed21534734bfc281759889e057.png)![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/d203a32aad0d46319b37554e293c9e47.png)

3、服务端组件调用

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/856f4a5635054539bb4bb1e037cc55c9.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/e320b08351ce4a9c95e179ea8ab36410.png)

## remoting分析

从上述代码中可以看出来，remoting这个工程，外部使用的话，还是比较简单的。

1、Netty Remoting Client

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/7b61d40edbd149d591a3d69dd6fe2c09.png)

虽然方法很多，但是一般的就是使用就是1，2，3步。

2、Netty Remoting Server

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/4c5ba9f00e8148a1b7197bd5d6392911.png)

虽然方法很多，但是一般的就是使用就是1，2，3步。

remoting 的网络通信是基于 Netty 实现，模块中类的继承关系如下：

![](https://img-blog.csdnimg.cn/img_convert/76cc3b916309b101f41e38e0f5c7f3d2.png)![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/e272e587e4a6472a85d8d70fb0cf49be.png)

## NettyRemotingServer分析

### 启动过程

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/93c783cb8fe840afb3f15a715d781692.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/8659fc8573cb4c40bed7bb36664fbd74.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/825d043b67e547e6a53e9ca0f16afb67.png)

### 服务端Handler

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/2d090c9f08ff443fa75de359d1d6172f.png)

1、HandshakeHandler

HandshakeHandler，第一个入站handler，当客户端配置useTLS=true时生效，为服务端动态创建SSLHandler

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/19065ef10b5548d8aea1b1fb32a6b658.png)

这个HandshakeHandler是一个入站处理器（Netty作为服务端，有数据请求过来），这里的代码简单的理解就是如果是生产者配置SSL的，那么就还需要加入Handler来处理SSL。这块不重要，所以我们pass掉。

2、NettyDecoder

解码器，根据长度字段解析数据包，解决拆包粘包问题

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/738f2c2ecd1e4911a2ce0257fa13355f.png)

NettyDecoder继承与LengthFieldBasedFrameDecoder，LengthFieldBasedFrameDecoder是一种把消息分成消息头和消息体的解码器。当然具体是怎么编码，不同急，我们看完下面的编码器就能明白。

3、NettyEncoder

编码器，按协议拼装报文。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/1daf5c45120d47329ffede9d732bb959.png)

这里的详细内容，我把它放下面的《RemotingCommand协议》章节中讲。

4、RemotingCodeDistributionHandler

用来计数的，根据请求的业务类型来计数

5、IdleStateHandler

Netty提供的一个非常实用的Handler，空闲连接检查，依赖defaultEventExecutorGroup线程执行调度任务，发现空闲连接触发IDLE事件，由NettyConnectManageHandler处理IDLE事件

用于检测连接是否空闲。它可以检测连接是否读空闲、写空闲或者读写空闲。在指定的时间间隔内，如果连接没有发生读写事件，IdleStateHandler会触发一个IdleStateEvent事件，以便开发者可以对连接进行自定义的操作，例如发送心跳包或关闭连接等。

6、NettyConnectManageHandler

连接管理，主要用来关闭连接

7、NettyServerHandler

处理具体业务逻辑

### RemotingCommand协议

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/26950e74013644618c89c764a9ad4004.png)

从这里可以看出，RocketMQ实现的协议是消息头+消息体的这种变长格式的协议。

所以我们从序列化的角度去看：

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/35ab4e6421c04769abc54d48a1e19096.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/a05d8e545bdd491784070c154a1f083b.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/3a04ee673502425c8ae9991993369e8f.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/03f80941c4aa4cb083f1bc8d9634146c.png)

大致总结下来就是以下这张图的样子：

前4个byte是总长度

4~8是头长度+消息类型

如果是json类型消息，还要写入一定长度的headerdata

后面的就是body，就是体信息了。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/093ac3964244485e9999b259c259614b.png)

**另外如果我们站在反序列化的角度来看**

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/508f0221b61a4417a23142b411f2205f.png)

decode方法是将ByteBuf转成Body，然而这个整体流程是怎样的，我们再可以继续看客户端网络组件的分析

## NettyRemotingClient分析

源码中有相关的测试代码。我们看一看即可知道客户端是怎么运行的。

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/047473dd74fb40d2aec621fe50813ba4.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/5eab877112a545ad96fc4b8f41c81a6f.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/c41804816f8445bcb67a87b1ec6b6f2b.png)

这里可以看到，也就是1、构造。2、start，3invoke的这种三步曲。

包括客户端同步调用、异步、单向调用就是不同的方法而已。

## NettyRemotingClient源码分析

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/0d8aca9f19bf4881b668c16bd408b42d.png)

## NettyRemotingServer的源码分析

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/f2ef075332a84bb0a0b794fe00768cc6.png)

## 技术亮点

### 1、同步调用的阻塞基于CountDownLatch

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/ab1ed5741a6e4459993030d5a6167d8a.png)

### 2、使用Semaphore来限流控制并发（异步发送）

Semaphore（信号量）是用来控制同时访问特定资源的线程数量，它通过协调各个线程，以保证合理的使用公共资源。

应用场景Semaphore可以用于做流量控制，特别是公用资源有限的应用场景，比如数据库连接。假如有一个需求，要读取几万个文件的数据，因为都是IO密集型任务，我们可以启动几十个线程并发地读取，但是如果读到内存后，还需要存储到数据库中，而数据库的连接数只有10个，这时我们必须控制只有10个线程同时获取数据库连接保存数据，否则会报错无法获取数据库连接。这个时候，就可以使用Semaphore来做流量控制。

Semaphore的构造方法Semaphore（int permits）接受一个整型的数字，表示可用的许可证数量。Semaphore的用法也很简单，首先线程使用Semaphore的acquire()方法获取一个许可证，使用完之后调用release()方法归还许可证。还可以用tryAcquire()方法尝试获取许可证。

RocketMQ中的使用

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/f7247ed310964ebb940bdcc69a448c97.png)

![image.png](https://fynotefile.oss-cn-zhangjiakou.aliyuncs.com/fynote/fyfile/5983/1684895033088/814f85bddb824f28b6d09fd966c59458.png)
